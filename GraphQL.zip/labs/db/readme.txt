blogging.db is a ready-to-use database

For the labs (9-15) nothing else is required!

Only in the case you want to create another database:

1. Open the folder create-db

2. Optionally update the db-script.sql

3. Run in a command prompt (not Powershell):
sqlite3.exe my_database_name.db ".read db-script.sql"


