# Lab 10 - Enums Extra

Enums can also come into play in scenario's where subscriptions are used.  
In this exercise we'll use a simplified API for users only (no blogs or comments).

Open as a starter the solution: 📂 _**lab10-START-enums-extra**_.

---

## 1. Inspect the current solution

4 migrations have been implemented:

- **`createUser`**
- **`updateUser`**
- **`changeUserStatus`**
- **`deleteUser`**

2 subscriptions have been implemented:

- **`userCreated`**
- **`userUpdated`**

---

## 2. Test

<details>
<summary><strong>Test: Subscription <code>userCreated</code></strong></summary>

```bash
subscription {
  userCreated {
    id
    firstname
    email
  }
}
```
</details>


<details>
<summary><strong>Test: Mutation <code>createUser</code></strong></summary>

```bash
mutation {
  createUser(input:{
    firstname: "Joop",
    email: "joop@alfa.com"
  }) {
    id
    firstname
  }
}
```
</details>

<details>
<summary><strong>Test: Subscription <code>userUpdated</code></strong></summary>

```bash
subscription {
  userUpdated(userID: 1) {
    id
    firstname
    email
  }
}
```
</details>

<details>
<summary><strong>Test: Mutation <code>updateUser</code></strong></summary>

```bash
mutation {
  updateUser(input: {
    id: 8,
    firstname: "Piet"
    email: "piet@alfa.com"
  }) {
    id
    firstname
    email
		status
  }
}
```
</details>

---
## 3. Add subscription

Provide clients with the possibility that by _one_ subscription they'll get notified when _any_ of the 4 mutations happen.  
Don't implement arguments for now!

The subscription shouldn't return a **`User`**, but an object of type **`UserModificationPayload`** with 2 properties:

- **`user`**: User!
- **`modification`**: UserModification!

You guessed it right! **`UserModification`** is an enum with the values:  
`CREATED`, `UPDATED`, `STATUSCHANGED` and `DELETED`.

1. Update the schema and resolvers. Topic name can be 'USER_MODIFIED'.

---

## 4. Test

<details>
<summary><strong>Test: Subscription <code>userModified</code></strong></summary>

```bash
subscription {
  userModified {
    user {
      id
      firstname
      birthdate
      status
    }
    modification
  }
}
```
</details>

<details>
<summary><strong>Test: Mutation <code>createUser</code></strong></summary>

```bash
mutation {
  createUser(input:{
    firstname: "Joop",
    email: "joop@alfa.com"
  }) {
    id
    firstname
  }
}
```
</details>


<details>
<summary><strong>Test: Mutation <code>updateUser</code></strong></summary>

```bash
mutation {
  updateUser(input: {
    id: 8,
    firstname: "Joop"
    email: "joop@beta.com"
  }) {
    id
    firstname
    email
		status
  }
}
```
</details>

<details>
<summary><strong>Test: Mutation <code>changeUserStatus</code></strong></summary>

```bash
mutation {
  changeUserStatus(input: {
    id: 8,
    status: EXPIRED
  }) {
    id
    status
    firstname
  }
}
```
</details>

<details>
<summary><strong>Test: Mutation <code>deleteUser</code></strong></summary>

```bash
mutation {
  deleteUser(input:{
    id: 8
  }) {
    id
    firstname
    status
  }
}
```
</details><br>

What is the great benefit of an enum here?  
Assume that you coded 'INSERTED' instead of 'CREATED' by accident ...  
As soon you'll subscribe a neat error message will be shown!
