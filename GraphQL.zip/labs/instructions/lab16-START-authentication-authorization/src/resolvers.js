const resolvers = {
  Query: {
    users: (_parent, _args, { db }) => db.users,
    serverTime: () => new Date().toISOString(),
  }
}

export default resolvers;
