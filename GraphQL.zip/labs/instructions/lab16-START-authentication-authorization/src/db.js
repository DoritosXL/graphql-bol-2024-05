const db = {};

db.users = [
  {
    id: 1,
    username: 'An',
    city: 'Urk',
  },
  {
    id: 2,
    username: 'Bo',
    city: 'Ede',
  },
];

export default db;
