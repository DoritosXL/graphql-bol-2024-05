

# Nieuwe labs?

1. Set up Apollo server die een podcast kan teruggeven
1. Lijst podcasts teruggeven en toevoegen inclusief variabelen
