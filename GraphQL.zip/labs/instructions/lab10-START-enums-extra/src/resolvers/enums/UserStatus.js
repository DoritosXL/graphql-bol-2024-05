const UserStatus = {
  REGISTERED: 'r',
  ACTIVE: 'a',
  DISABLED: 'd',
  EXPIRED: 'e',
};

export default UserStatus;