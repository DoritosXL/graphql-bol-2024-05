const Mutation = {
  createUser: async (_parent, { input }, { prisma, pubsub }) => {
    const user = await prisma.users.create({
      data: {
        ...input,
        status: 'r',
      }
    });

    pubsub.publish(
      'USER_CREATED',
      { userCreated: user }
    )

    return user;
  },
  updateUser: async (_parent, { input }, { prisma, pubsub }) => {
    const { id } = input;
    const data = { ...input };
    delete data.id;

    try {
      const user = await prisma.users.update({
        data,
        where: {
          id: +id,
        },
      });

      pubsub.publish(
        'USER_UPDATED_' + id, 
        { userUpdated: user }
      )

      return user;
    } catch (err) {
      throw new Error(err.toString());
    }
  },
  changeUserStatus: async(_parent, { input }, { prisma }) => {
    const { id, status } = input;
  
    try {
      const user = await prisma.users.update({
        data: {
          status,
        },
        where: {
          id: +id,
        },
      });

      return user;
    } catch (err) {
      throw new Error(err.toString());
    }
  },
  deleteUser: async (_parent, { input }, { prisma }) => {
    const { id } = input;
    try {
      const user = await prisma.users.delete({
        where: {
          id: +id,
        }
      });

      return user;
    } catch(err) {
      throw new Error(err.toString());
    }
  },
};

export default Mutation;