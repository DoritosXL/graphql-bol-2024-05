import { gql } from 'apollo-server';

const typeDefs = gql`
  type Query {
    users: [User!]!
  }

  type Mutation {
    createUser(input: CreateUserInput!): User!
    updateUser(input: UpdateUserInput): User!
    changeUserStatus(input: ChangeUserStatusInput!): User!
    deleteUser(input: DeleteUserInput): User!
    
  }

  type Subscription {
    userCreated: User!
    userUpdated(userID: ID!): User!
  }

  type User {
    id: ID!
    firstname: String!
    email: String
    birthdate: String
    status: UserStatus!
  }

  input CreateUserInput {
    firstname: String!
    email: String
    birthdate: String
  }

  input UpdateUserInput {
    id: ID!
    firstname: String
    email: String
    birthdate: String
  }

  input ChangeUserStatusInput {
    id: ID!
    status: UserStatus!
  }

  input DeleteUserInput {
    id: ID!
  }
  
  enum UserStatus {
    REGISTERED
    ACTIVE
    DISABLED
    EXPIRED
  }
`;

export default typeDefs;
