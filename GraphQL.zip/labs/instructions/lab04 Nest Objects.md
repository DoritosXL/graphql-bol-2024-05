# Lab 4 - Nest Objects

A blogging app with only users doesn't make sense. Let's add some blogs!

---

## 1. Blog

Extend the graph with a new object type _`Blog`_. Don't bother about relations yet!  
In this part of the lab you'll repeat steps from previous labs.

1. Update the data source:

   (copy-paste):

   ```js
   const blogs = [
     {
       id: 'b1',
       title: 'blog A',
       content: 'Content of Blog A',
       published: true,
     },
     {
       id: 'b2',
       title: 'blog B',
       content: 'Content of Blog B',
       published: true,
     },
     {
       id: 'b3',
       title: 'blog C',
       content: 'Content of Blog C',
       published: false,
     },
   ];
   ```

1. Update the **schema** and **resolver map** to extend the graph:

- Blog type:

  | Fieldname | Type    | Nullable |
  | --------- | ------- | -------- |
  | id        | ID      | no       |
  | title     | String  | no       |
  | content   | String  | no       |
  | published | Boolean | no       |

<br>

- Third entry point in the root type:

  | Fieldname | Type | Nullable |
  | --------- | ---- | -------- |
  | blogs     | Blog | no       |

3. Test the new entry point in Playground:

   <details>
   <summary>Test!</summary>

   ```bash
   query {
     blogs {
       id
       title
       content
       published
     }
   }
   ```

   </details>

---

## 2. Nest User in Blog

Both objects _`User`_ and _`Blog`_ are related. The tables in a relational database might look like:

![ER diagram](img/er-diagram1.png)

However our graph won't be a one-to-one copy of the database. Instead, we'll structure types and name fields in such a way that clients can query intuitively.

1. Update the **data source**. Add a field **`userid`** to all blogs:

   (copy - paste)

   ```js
   const blogs = [
     {
       id: 'b1',
       title: 'blog A',
       content: 'Content of Blog A',
       published: true,
       userid: 'u1',
     },
     {
       id: 'b2',
       title: 'blog B',
       content: 'Content of Blog B',
       published: true,
       userid: 'u2',
     },
     {
       id: 'b3',
       title: 'blog C',
       content: 'Content of Blog C',
       published: false,
       userid: 'u1',
     },
   ];
   ```

1. Update the **schema**:  
   The **`Blog`** type should have a non-nullable **`creator`** field of type **`User`**.

1. Update the **resolver map**:
   The **`creator`** field is an object type, so a resolver needs to be coded. Code is given, next time you're on your own:

   ```js
   const resolvers = {
     Query: {
       // ... 3 entry points
     },
     Blog: {
       creator(parent) {
         return db.users.find((user) => user.id === parent.userid);
       },
     },
   };
   ```

   Whenever the client decides to show fields of the **`creator`**, the resolver function is called:

   - **`creator`** must be defined _within_ **`Blog`**
   - the **`parent`** argument of the creator resolver contains all fields of the blog (including the **`userid`**).  
     Note that if there are 3 blogs, this resolver is called 3 times.
   - **`find()`** is a built-in JavaScript array method

    <details>
    <summary>Test!</summary>

   ```bash
   query {
     blogs {
       title
       content
       published
       creator {
         firstname
         email
         yearOfBirth
       }
     }
   }
   ```

    </details>

---

## 3. Nest blogs in `User`

In the previous exercise details of a creator can be fetched when querying blogs.

Let's now implement logic which allows clients to also query the other way around:  
_blogs can be fetched when querying users_.

1. No need to update the data source as there is already a relation. Only extend the graph by updating the **schema** and **resolver map**.  
   tip: in the resolver function use the JavaScript array method **`filter()`**

    <details>
    <summary>Test!</summary>

   ```bash
   query {
     users {
       firstname
       blogs {
         id
         title
       }
     }
   }
   ```

    </details><br>

---

🔔 We've build a very flexible graph which even allow for silly queries like:

```bash
query {
  users {
    firstname
    blogs {
      title
      creator {
        firstname
        blogs {
          title
        }
      }
    }
  }
}
```

With a lot of data and a lot of levels in a query, the GraphQL Server could become overloaded and less performant.  
 Hackers could use this type of queries for a Denial of Service (DoS) attack.

Many GraphQL libraries support features to limit the allowed number of levels.  
 More info on _DoS prevention_:  
 https://cheatsheetseries.owasp.org/cheatsheets/GraphQL_Cheat_Sheet.html
