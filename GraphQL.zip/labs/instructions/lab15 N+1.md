# Lab 15 - N+1

To solve a 'N+1 bottleneck' in a GraphQL API, Facebook's Dataloader may be the simplest solution.

Although Prisma ORM has got built-in batch functionality, we will explicity implement a Dataloader for practice.

Let's assume that the current resolver for retrieving Blog creators takes too much time:

```js
const Blog = {
  creator: async (parent, _args, { prisma }) => {
    return await prisma.users.findUnique({
      where: {
        id: parent.userid,
      },
    });
  },
};
```

---

## 1. Implement Dataloader

1. Stop the server

1. Install Dataloader:

   ```bash
   npm install dataloader
   ```

1. Start the server

1. In 📂 **_src_** ad 📂 **_dataloaders_**. Add 📄 **_creatorLoader.js_**.

1. Define the batchfunction and add it in the constructor of the Dataloader:

   ```js
   import DataLoader from 'dataloader';

   import pkg from '@prisma/client';
   const { PrismaClient } = pkg;
   const prisma = new PrismaClient();

   const creatorBatchFunction = async (keys) => {
     // 👇 part 1: single database request to get all needed users
     const creators = await prisma.users.findMany({
       where: {
         id: {
           in: keys,
         },
       },
     });

     // 👇 part 2: structure expected by the data loader
     const creatorMap = {};
     creators.forEach((creator) => {
       creatorMap[creator.id] = creator;
     });

     return keys.map((key) => creatorMap[key]);
   };

   export default new DataLoader(creatorBatchFunction);
   ```

1. Import the dataloader and share it in GraphQL's context:

   ```js
   import creatorLoader from './dataloaders/creatorLoader.js'; // 👈

   // ...

   const server = new ApolloServer({
     // ...
     context: {
       prisma,
       creatorLoader, // 👈
     },
     // ...
   });
   ```

1. Replace the **`Blog`** resolver:

   ```js
   creator: (parent, _args, { creatorLoader }) => {
     console.log(parent.id);
     return creatorLoader.load(parent.id);
   },
   ```

1. Test. The solution should work fine.

---
(if time permits)

## 2. Refactor

1. Refactor the code in such a way that the Prisma import in 📄 **_creatorLoader.js_** is not necessary anymore.

   In 📄 **_server.js_** the code could look like:

   ```js
   context: {
     prisma,
     creatorLoader: getCreatorLoader(prisma),
   },
   ```
