# Lab 11 - Abstract Types

In this lab we will practise with the two abstract types: _interface_ and _union_.

---

## 1. Implement Interface

Wouldn't it be great to get one list of published items wheter they are blogs or comments?  
Blogs and comments have the field **`published`** in common.

Let's build and implement a **`Publishable`** interface.

1. Add the interface and enforce 2 types to implement the field **`published`**.

   **schema**

   ```bash
     type Query {
       items: [Publishable!]!                # 👈 new entry point
       # ...
     }

     type Blog implements Publishable {      # 👈 contract: add published!!
       # ...
       published: Boolean!
     }

     type Comment implements Publishable {   # 👈 contract: add published!!
       # ...
       published: Boolean!
     }

     interface Publishable {                 # 👈 define interface
       published: Boolean!
     }
   `;
   ```

1. Add a resolver for the new entry point **`items`**.

   ```js
   const Query = {
     items: async (_parent, _args, { prisma }) => {
       const blogs = await prisma.blogs.findMany();
       const comments = await prisma.comments.findMany();

       return [...blogs, ...comments];
     },
     // ...
   ```

1. In 📂 **_src_** add 📂 **_abstracts_** with 📄 **_Publishable.js_**.

   Code the special **`__resolveType`** resolver.

   ```js
   const Publishable = {
     __resolveType(item, _context, _info) {
       if (item.title) return 'Blog';
       if (item.blogid) return 'Comment';
       return null; // show GraphQLError
     },
   };

   export default Publishable;
   ```

1. Update the server accordingly.

   ```js
   import Publishable from './abstracts/Publishable.js';   // 👈

   const server = new ApolloServer({
     typeDefs,
     resolvers: {
       Publishable,  👈
       // ...
     },
     // ...
   });
   ```

    <details>
    <summary>Test: show published field for both entries</summary>

   ```bash
   query {
     items {
       published
     }
   }
   ```

    </details>

    <details>
    <summary>Test: add some details for blogs</summary>

   ```bash
   query {
     items {
       published
       ... on Blog {
         title
         content
         creator {
           firstname
         }
       }
     }
   }
   ```

    </details>

    <details>
    <summary>Test: add some details for comments</summary>

   ```bash
   query {
     items {
       published
       ... on Blog {
         title
         content
         creator {
           firstname
         }
       }
       ... on Comment {
         content
       }
     }
   }
   ```

    </details>

    <details>
    <summary>Test: add <strong><code>__typename</code></strong> as well</summary>

   ```bash
   query {
     items {
       published
       __typename
       ... on Blog {
         title
         content
         creator {
           firstname
         }
       }
       ... on Comment {
         content
       }
     }
   }
   ```

    </details>

---

## 2. Implement Union

1. Add the next fields for the **`Blog`** type to the GraphQL schema:

   | Fieldname          | Type    | Nullable |
   | ------------------ | ------- | -------- |
   | price              | Float   | yes      |
   | availableDate      | String  | yes      |
   | availableInCountry | Boolean | yes      |

1. Inspect the new fields of the blogs:

    <details>
    <summary>Test!</summary>

   ```bash
   query {
     blogs {
       id
       title
       price
       availableDate
       availableInCountry
     }
   }
   ```

    </details><br>

   The first 2 blogs have a price. The last 3 blogs haven't, reasons:

   - blog3 - **`availableDate`** is in the future
   - blog4,5 - **`availableInCountry`** = false  

   For blogs 3, 4 and 5 we don't need to retrieve fields like **`price`** or **`availableInCountry`**. Instead it would be beneficial to show relevant info in those cases. For example in which countries is the blog available?

   A union will allow for that!

1. Test the entry point **`blogById(id: ID!): Blog!`**

   <details>
   <summary>Test!</summary>

   ```bash
   query {
     blogById(id: 1) {
       id
       title
       price
       availableDate
       availableInCountry
     }
   }
   ```

   </details><br>

1. Add two new Object types and a union:

   **schema**

   ```bash
   type NotAvailableYet {            # 👈 must be an Object
     availableDate: String!
   }

   type NotAvailableInCountry {      # 👈 must be an Object
      availableInCountry: Boolean!
   }

   # 👇 the union
   union BlogResult = Blog | NotAvailableYet | NotAvailableInCountry
   ```

1. Use the union in the entry point:

   ```bash
   # blogById(id: ID!): Blog!
   blogById(id: ID!): BlogResult!
   ```

1. Create another **`__resolveType`** resolver:

   a. In 📂 **_abstracts_** add 📄 **_BlogResult.js_**.

   b. Add the code:

   ```js
   const BlogResult = {
     __resolveType(item, _context, _info) {
       if (item.availableDate) return 'NotAvailableYet';
       if (!item.availableInCountry) return 'NotAvailableInCountry';
       if (item.price) return 'Blog';
       return null; // show GraphQLError
     },
   };

   export default BlogResult;
   ```

   c. Update the server accordingly.

1. Write a test where the union is used.

   <details>
   <summary>Test!</summary>

   ```bash
   query {
     blogById(id: 3) {   # 👈 test 1 - 5
       ... on Blog {
         title
         price
       }

       ... on NotAvailableYet {
         availableDate
       }

       ... on NotAvailableInCountry {
         availableInCountry
       }
     }
   }
   ```

   </details>

---

(if time permits)

## 3. Improve

All queries return wonderful results. To further improve, let's show a list of available countries when a blog is not available in the country (**`availableInCountry`** = false).

To retrieve these countries database _joins_ are necessary with the tables **`BlogsOnCountries`** and **`Countries`**. Furthermore, this additional logic needs to be executed _only_ when **`availableInCountry`** = false.

1. Add a new type **`Country`**.

   **schema**

   ```bash
   type Country {
     id: ID!
     name: String!
   }
   ```

1. Update the type **`NotAvailableInCountry`**:

   ```bash
   type NotAvailableInCountry {
     availableInCountries: [Country!]!
   }
   ```

   Note: don't change type **`Blog`**.

1. Now the challenging part. The optional retrieval of available countries must happen in the **`blogById()`** resolver.

   If the field **`availableCountry`** is false:

   - retrieve countries via the 2 additional tables
   - fill an array with country objects, each object has got an **`id`** and **`name`** field
   - attach this array to the blog which is returned

   **Query.js**

   ```js
   blogById: async (_parent, { id }, { prisma }) => {
     const res = await prisma.blogs.findUnique({
       where: {
         id: +id
       }
     });

     if (!res.availableInCountry) {
       const countries = await prisma.blogsOnCountries.findMany({
         where: {
           blogid: +id
         },
         include: {
           country: true,
         },
       });

       res.availableInCountries = countries.map((elem) => elem.country);
     }

     return res;
   },
   ```

1. Update the last test to now show **`id`** and **`name`** of found countries.

   <details>
   <summary>Test!</summary>

   ```bash
   query {
     blogById(id: 5) {
       ... on Blog {
         title
         price
       }

       ... on NotAvailableYet {
         availableDate
       }

       ... on NotAvailableInCountry {
         availableInCountries {        # 👈 update this part
           id
           name
         }
       }
     }
   }
   ```

   </details>
