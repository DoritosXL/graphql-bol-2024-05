# Lab 8 - Realtime Data (optional)

In the previous lab we added a couple of mutations. Let's now give clients the possibility to be informed realtime whenever an event has taken place like the creation of a new user. Let's use a simplified API with basic support for **`users`** and **`blogs`**.

As we use the latest version of Apollo-Server, only for this lab 📄 **_server.js_** has been modified:

- integrate with **Express** - a popular and flexible web application framework for Nodejs
- build an executable schema to be used by both the Apollo server and the subscription server

Open as a starter 📂 **_lab08-START-realtime-data-optional_**.

## 1. Test 2 queries and 3 mutations

**users**

```bash
query {
  users {
    id
    firstname
    email
    yearOfBirth
    blogs {
      id
      content
    }
  }
}
```

**blogs**

```bash
query {
  blogs {
    id
    published
    title
    content
    creator {
      id
      firstname
    }
  }
}
```

**createUser**

```bash
mutation {
  createUser(
    input: {
      firstname: "Francis"
      email: "francis@live.com"
      yearOfBirth: 1992
    }
  ) {
    id
    firstname
    email
    yearOfBirth
    blogs {
      title
    }
  }
}
```

**updateUser**

```bash
mutation {
  updateUser(input: { id: "u1", firstname: "Frank", yearOfBirth: 1988 }) {
    id
    firstname
    email
    yearOfBirth
  }
}
```

**createBlog**

```
mutation {
  createBlog (input: {
    title: "Blog D",
    content: "Content of Blog D",
    creatorID: "u1"
  }) {
    id
    title
    content
    published
    creator {
      id
      firstname
    }
  }
}
```

## 2. Update server

1. Stop the server.

1. Intall 3 new dependencies:

   ```bash
   npm install subscriptions-transport-ws graphql graphql-subscriptions
   ```

1. In 📄 **_server.js_** add next import statements.

   ```js
   import { SubscriptionServer } from 'subscriptions-transport-ws';
   import { execute, subscribe } from 'graphql';
   import { PubSub } from 'graphql-subscriptions';
   ```

1. Within the function **`start()`**, above the line with the **`listen`** statement, instantiate a new subscription server:

   ```js
   const subscriptionServer = SubscriptionServer.create(
     {
       schema,
       execute,
       subscribe,
       async onConnect() {
         // returned object is passed as the `context` argument to the subscription resolvers
         return { db };
       },
     },
     {
       server: httpServer,
       path: server.graphqlPath,
     }
   );
   ```

1. Within the ApolloServer constructor add a second plugin which will close the subscription server when Apollo server is closed.

   ```js
   plugins: [
     ApolloServerPluginLandingPageGraphQLPlayground(),
     {
       async serverWillStart() {
         return {
           async drainServer() {
             subscriptionServer.close();
           },
         };
       },
     },
   ],
   ```

1. Start the server and retest.

## 3. Get notified when users are created

1. In the schema add a new root type: **`subscriptions`**.

   **typeDefs.js**

   ```bash
   type Subscription {
     userCreated: User!
   }
   ```

1. Setup **`PubSub`** in the entry file.

   **server.js**

   ```js
   import { PubSub } from 'graphql-subscriptions';
   ```

   ```js
   const pubsub = new PubSub();
   ```

1. Resolvers of both Apollo server and the Subscription server should be able to use this instance of PubSub, so add it to each context.

   **Apollo server**:

   ```js
   context: {
     db,
     pubsub,
   },
   ```

   **Subscription server**:

   ```js
   async onConnect() {
     // returned object is passed as the `context` argument to the subscription resolvers
     return {
       db,
       pubsub
     };
   },
   ```

1. To publish events to pubsub, update the **`createUser()`** resolver:  
   a. destructure pubsub in the 3rd argument  
   b. publish the event just after updating the data source

   **Mutation.js**

   ```js
   createUser: (_parent, { input }, { db, pubsub }) => {
     const user = { id: UUID(), ...input };
     db.users.push(user);

     pubsub.publish(
       'USER_CREATED',         // topic AKA channel name
       { userCreated: user }   // the payload, 'userCreated' mirrors the schema!
     );

     return user;
   },
   ```

1. Add the Subscription Resolver.

   a. In 📂 **_resolvers_** add 📄 **_Subscription.js_**  
   b. Add a **_`userCreated`_ object** with a **_`subscribe()`_ method**  
   c. destructure pubsub in the 3rd argument

   **Subscription.js**

   ```js
   const Subscription = {
     userCreated: {
       subscribe: (_parent, _args, { pubsub }) => {
         /* code to come */
       },
     },
   };

   export default Subscription;
   ```

1. To use this resolver make next changes:

   **resolvers.js**

   ```js
   import Subscription from './resolvers/Subscription.js';
   // ...
   export default { /* ... */, Subscription };
   ```

1. Within the **`subscribe()`** method add the logic which returns an **`asyncIterator()`** function to future subscribing clients. Use exactly the same topic name as defined earlier:

   ```js
   subscribe: (_parent, _args, { pubsub }) => {
     return pubsub.asyncIterator('USER_CREATED');
   },
   ```

    <details>
    <summary>Test!</summary>

   ```bash
   subscription {
     userCreated {
       id
       firstname
     }
   }
   ```

    </details>

Start the test and afterwards run the **`createUser()`** mutation.
Check the results returned from the subscription aftwards.

---

## 4. Get notified when a specific user is updated

In this scenario the client will provide a user id argument.

1. Update the schema.

   ```bash
   userUpdated(userID: ID!): User!
   ```

1. Publish an event to pubsub when an **`updateUser()`** mutation takes place:

   ```js
   // ...

   pubsub.publish('USER_UPDATED_' + id, { userUpdated: user });

   return user;
   ```

1. Create a new Subscription resolver with 3rd argument **`{ userID }`**. Use:

   ```js
   return pubsub.asyncIterator('USER_UPDATED_' + userID);
   ```

1. Add a subscription and test.

   <details>
   <summary>Test!</summary>

   ```bash
   subscription {
     userUpdated(userID: "u1") {
       id
       firstname
       email
     }
   }
   ```

   </details>

---

(if time permits)

## 5. Get notified when a specific user creates a blog

1. Try to implement all logic by yourself. Test your solution with:

   ```bash
   subscription {
     blogCreated(userID: "u1") {
       id
       title
       content
       published
       creator {
         id
         email
       }
     }
   }
   ```

---

More information on enabling subscription in Apollo Server v3:  
https://www.apollographql.com/docs/apollo-server/data/subscriptions/
