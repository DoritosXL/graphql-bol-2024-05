import express from 'express';
import { createServer } from 'http';
import { ApolloServer } from 'apollo-server-express';
import { makeExecutableSchema } from '@graphql-tools/schema';
import { ApolloServerPluginLandingPageGraphQLPlayground }  from 'apollo-server-core';
import resolvers from './resolvers.js';
import typeDefs from './typeDefs.js';
import db from './db.js';

async function start() {
  const app = express();
  const httpServer = createServer(app);

  const schema = makeExecutableSchema({
    typeDefs,
    resolvers,
  });

  const server = new ApolloServer({
    schema,
    context: { db },
    plugins: [ ApolloServerPluginLandingPageGraphQLPlayground() ],
  });
  
  await server.start();
  server.applyMiddleware({ app, path: '/' });

  httpServer.listen(4000, () => console.log(`🚀 Server is running on http://localhost:4000`));
};

start();